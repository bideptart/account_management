import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Eye, Download, FileText, File } from "lucide-react";
import { Document } from "@shared/schema";

interface DocumentTableProps {
  documents: (Document & { formattedSize?: string })[];
  isLoading: boolean;
  onDocumentAction: (action: 'view' | 'download', document: Document) => void;
}

const getFileIcon = (fileType: string) => {
  switch (fileType.toLowerCase()) {
    case '.pdf':
      return '📄';
    case '.doc':
    case '.docx':
      return '📝';
    case '.xls':
    case '.xlsx':
      return '📊';
    case '.csv':
      return '📋';
    default:
      return '📄';
  }
};

const getFileTypeColor = (fileType: string) => {
  switch (fileType.toLowerCase()) {
    case '.pdf':
      return 'bg-red-100 text-red-800';
    case '.doc':
    case '.docx':
      return 'bg-blue-100 text-blue-800';
    case '.xls':
    case '.xlsx':
      return 'bg-green-100 text-green-800';
    case '.csv':
      return 'bg-orange-100 text-orange-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

const getSyncStatusColor = (status: string) => {
  switch (status) {
    case 'synced':
      return 'bg-green-100 text-green-800';
    case 'syncing':
      return 'bg-yellow-100 text-yellow-800';
    case 'failed':
      return 'bg-red-100 text-red-800';
    case 'pending':
      return 'bg-gray-100 text-gray-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export function DocumentTable({ documents, isLoading, onDocumentAction }: DocumentTableProps) {
  if (isLoading) {
    return (
      <div className="p-8 text-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-gray-600">Loading documents...</p>
      </div>
    );
  }

  if (documents.length === 0) {
    return (
      <div className="p-8 text-center">
        <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No documents found</h3>
        <p className="text-gray-600">Upload your first document to get started.</p>
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Document</TableHead>
          <TableHead>Type</TableHead>
          <TableHead>Size</TableHead>
          <TableHead>Upload Date</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {documents.map((document) => (
          <TableRow key={document.id} className="hover:bg-gray-50">
            <TableCell>
              <div className="flex items-center space-x-3">
                <div className="text-2xl">
                  {getFileIcon(document.fileType)}
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-900">{document.originalName}</div>
                  {document.description && (
                    <div className="text-sm text-gray-500">{document.description}</div>
                  )}
                </div>
              </div>
            </TableCell>
            <TableCell>
              <Badge className={getFileTypeColor(document.fileType)}>
                {document.fileType.toUpperCase().replace('.', '')}
              </Badge>
            </TableCell>
            <TableCell className="text-sm text-gray-900">
              {document.formattedSize || `${(document.fileSize / 1024 / 1024).toFixed(2)} MB`}
            </TableCell>
            <TableCell className="text-sm text-gray-900">
              {new Date(document.uploadedAt).toLocaleDateString()}
            </TableCell>
            <TableCell>
              <Badge className={getSyncStatusColor(document.syncStatus)}>
                {document.syncStatus === 'synced' && '✓ Synced'}
                {document.syncStatus === 'syncing' && '↻ Syncing'}
                {document.syncStatus === 'failed' && '✗ Failed'}
                {document.syncStatus === 'pending' && '⏳ Pending'}
              </Badge>
            </TableCell>
            <TableCell className="text-right">
              <div className="flex items-center justify-end space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDocumentAction('view', document)}
                  className="text-primary hover:text-blue-800 hover:bg-blue-50"
                >
                  <Eye className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDocumentAction('download', document)}
                  className="text-gray-600 hover:text-gray-800 hover:bg-gray-50"
                >
                  <Download className="w-4 h-4" />
                </Button>
              </div>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
