import {
  users,
  documents,
  userFolders,
  type User,
  type UpsertUser,
  type Document,
  type InsertDocument,
  type UpdateDocument,
  type UserFolder,
  type InsertUserFolder,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, like, or } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Document operations
  createDocument(document: InsertDocument): Promise<Document>;
  getDocument(id: number): Promise<Document | undefined>;
  getDocumentsByUser(userId: string): Promise<Document[]>;
  getAllDocuments(): Promise<(Document & { user: User })[]>;
  updateDocument(id: number, updates: UpdateDocument): Promise<Document>;
  deleteDocument(id: number): Promise<void>;
  searchDocuments(query: string, userId?: string): Promise<Document[]>;
  
  // User folder operations
  createUserFolder(folder: InsertUserFolder): Promise<UserFolder>;
  getUserFolder(userId: string): Promise<UserFolder | undefined>;
  
  // Admin operations
  getAllUsers(): Promise<User[]>;
  getUserStats(): Promise<{
    totalUsers: number;
    totalDocuments: number;
    totalStorage: number;
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Document operations
  async createDocument(document: InsertDocument): Promise<Document> {
    const [newDocument] = await db
      .insert(documents)
      .values(document)
      .returning();
    return newDocument;
  }

  async getDocument(id: number): Promise<Document | undefined> {
    const [document] = await db
      .select()
      .from(documents)
      .where(eq(documents.id, id));
    return document;
  }

  async getDocumentsByUser(userId: string): Promise<Document[]> {
    return await db
      .select()
      .from(documents)
      .where(eq(documents.userId, userId))
      .orderBy(desc(documents.uploadedAt));
  }

  async getAllDocuments(): Promise<(Document & { user: User })[]> {
    return await db
      .select({
        id: documents.id,
        userId: documents.userId,
        fileName: documents.fileName,
        originalName: documents.originalName,
        fileType: documents.fileType,
        fileSize: documents.fileSize,
        mimeType: documents.mimeType,
        googleDriveFileId: documents.googleDriveFileId,
        googleDriveFolderId: documents.googleDriveFolderId,
        syncStatus: documents.syncStatus,
        localPath: documents.localPath,
        description: documents.description,
        uploadedAt: documents.uploadedAt,
        updatedAt: documents.updatedAt,
        user: users,
      })
      .from(documents)
      .innerJoin(users, eq(documents.userId, users.id))
      .orderBy(desc(documents.uploadedAt));
  }

  async updateDocument(id: number, updates: UpdateDocument): Promise<Document> {
    const [updated] = await db
      .update(documents)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(documents.id, id))
      .returning();
    return updated;
  }

  async deleteDocument(id: number): Promise<void> {
    await db.delete(documents).where(eq(documents.id, id));
  }

  async searchDocuments(query: string, userId?: string): Promise<Document[]> {
    const conditions = [
      or(
        like(documents.fileName, `%${query}%`),
        like(documents.originalName, `%${query}%`),
        like(documents.description, `%${query}%`)
      )
    ];

    if (userId) {
      conditions.push(eq(documents.userId, userId));
    }

    return await db
      .select()
      .from(documents)
      .where(and(...conditions))
      .orderBy(desc(documents.uploadedAt));
  }

  // User folder operations
  async createUserFolder(folder: InsertUserFolder): Promise<UserFolder> {
    const [newFolder] = await db
      .insert(userFolders)
      .values(folder)
      .returning();
    return newFolder;
  }

  async getUserFolder(userId: string): Promise<UserFolder | undefined> {
    const [folder] = await db
      .select()
      .from(userFolders)
      .where(eq(userFolders.userId, userId));
    return folder;
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .orderBy(desc(users.createdAt));
  }

  async getUserStats(): Promise<{
    totalUsers: number;
    totalDocuments: number;
    totalStorage: number;
  }> {
    const userCount = await db
      .select()
      .from(users);
    
    const docStats = await db
      .select()
      .from(documents);

    const totalStorage = docStats.reduce((sum, doc) => sum + doc.fileSize, 0);

    return {
      totalUsers: userCount.length,
      totalDocuments: docStats.length,
      totalStorage,
    };
  }
}

export const storage = new DatabaseStorage();
