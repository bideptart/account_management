import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { upload, formatFileSize, deleteFile } from "./services/fileUpload";
import { googleDriveService } from "./services/googleDrive";
import { insertDocumentSchema, updateDocumentSchema } from "@shared/schema";
import { z } from "zod";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Document routes
  app.post('/api/documents/upload', isAuthenticated, upload.array('files', 5), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const files = req.files as any[];
      if (!files || files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }

      const uploadedDocuments = [];

      for (const file of files) {
        try {
          // Create user folder in Google Drive if it doesn't exist
          let userFolder = await storage.getUserFolder(userId);
          if (!userFolder) {
            const folderName = `${user.firstName || ''}_${user.lastName || ''}_${user.email}`.replace(/\s+/g, '_');
            const googleDriveFolderId = await googleDriveService.createUserFolder(
              folderName,
              user.email || ''
            );
            
            userFolder = await storage.createUserFolder({
              userId,
              googleDriveFolderId,
              folderName,
            });
          }

          // Upload to Google Drive
          const googleDriveFileId = await googleDriveService.uploadFile(
            file.path,
            file.originalname,
            file.mimetype,
            userFolder.googleDriveFolderId
          );

          // Save document metadata to database
          const documentData = {
            userId,
            fileName: file.filename,
            originalName: file.originalname,
            fileType: path.extname(file.originalname).toLowerCase(),
            fileSize: file.size,
            mimeType: file.mimetype,
            googleDriveFileId,
            googleDriveFolderId: userFolder.googleDriveFolderId,
            syncStatus: 'synced' as const,
            localPath: file.path,
            description: req.body.description || '',
          };

          const validatedData = insertDocumentSchema.parse(documentData);
          const document = await storage.createDocument(validatedData);
          uploadedDocuments.push(document);

        } catch (error) {
          console.error(`Error processing file ${file.originalname}:`, error);
          // Clean up local file if upload failed
          await deleteFile(file.path);
          
          // Save document with failed sync status
          const documentData = {
            userId,
            fileName: file.filename,
            originalName: file.originalname,
            fileType: path.extname(file.originalname).toLowerCase(),
            fileSize: file.size,
            mimeType: file.mimetype,
            syncStatus: 'failed' as const,
            localPath: file.path,
            description: req.body.description || '',
          };

          const validatedData = insertDocumentSchema.parse(documentData);
          const document = await storage.createDocument(validatedData);
          uploadedDocuments.push(document);
        }
      }

      res.json({
        message: "Files uploaded successfully",
        documents: uploadedDocuments,
      });

    } catch (error) {
      console.error("Error uploading files:", error);
      res.status(500).json({ message: "Failed to upload files" });
    }
  });

  app.get('/api/documents', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const documents = await storage.getDocumentsByUser(userId);
      
      const documentsWithFormattedSize = documents.map(doc => ({
        ...doc,
        formattedSize: formatFileSize(doc.fileSize),
      }));

      res.json(documentsWithFormattedSize);
    } catch (error) {
      console.error("Error fetching documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.get('/api/documents/:id/download', isAuthenticated, async (req: any, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      const document = await storage.getDocument(documentId);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }

      // Check if user owns the document or is admin
      if (document.userId !== userId && !user?.isAdmin) {
        return res.status(403).json({ message: "Access denied" });
      }

      if (document.localPath) {
        res.download(document.localPath, document.originalName);
      } else if (document.googleDriveFileId) {
        // Download from Google Drive
        const tempPath = path.join(process.cwd(), 'temp', `${document.id}_${document.originalName}`);
        await googleDriveService.downloadFile(document.googleDriveFileId, tempPath);
        res.download(tempPath, document.originalName, () => {
          // Clean up temp file
          deleteFile(tempPath);
        });
      } else {
        res.status(404).json({ message: "File not found" });
      }
    } catch (error) {
      console.error("Error downloading document:", error);
      res.status(500).json({ message: "Failed to download document" });
    }
  });

  app.delete('/api/documents/:id', isAuthenticated, async (req: any, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      const document = await storage.getDocument(documentId);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }

      // Check if user owns the document or is admin
      if (document.userId !== userId && !user?.isAdmin) {
        return res.status(403).json({ message: "Access denied" });
      }

      // Delete from Google Drive
      if (document.googleDriveFileId) {
        try {
          await googleDriveService.deleteFile(document.googleDriveFileId);
        } catch (error) {
          console.error("Error deleting from Google Drive:", error);
        }
      }

      // Delete local file
      if (document.localPath) {
        await deleteFile(document.localPath);
      }

      // Delete from database
      await storage.deleteDocument(documentId);

      res.json({ message: "Document deleted successfully" });
    } catch (error) {
      console.error("Error deleting document:", error);
      res.status(500).json({ message: "Failed to delete document" });
    }
  });

  // Admin routes
  app.get('/api/admin/documents', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const documents = await storage.getAllDocuments();
      const documentsWithFormattedSize = documents.map(doc => ({
        ...doc,
        formattedSize: formatFileSize(doc.fileSize),
      }));

      res.json(documentsWithFormattedSize);
    } catch (error) {
      console.error("Error fetching all documents:", error);
      res.status(500).json({ message: "Failed to fetch documents" });
    }
  });

  app.get('/api/admin/users', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getUserStats();
      res.json({
        ...stats,
        formattedStorage: formatFileSize(stats.totalStorage),
      });
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.put('/api/admin/documents/:id', isAuthenticated, async (req: any, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);

      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const updates = updateDocumentSchema.parse(req.body);
      const updatedDocument = await storage.updateDocument(documentId, updates);

      res.json(updatedDocument);
    } catch (error) {
      console.error("Error updating document:", error);
      res.status(500).json({ message: "Failed to update document" });
    }
  });

  // Search routes
  app.get('/api/search/documents', isAuthenticated, async (req: any, res) => {
    try {
      const { q: query, userId: searchUserId } = req.query;
      const currentUserId = req.user.claims.sub;
      const user = await storage.getUser(currentUserId);

      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }

      // Regular users can only search their own documents
      let finalUserId = currentUserId;
      if (user?.isAdmin && searchUserId) {
        finalUserId = searchUserId as string;
      }

      const documents = await storage.searchDocuments(query, finalUserId);
      const documentsWithFormattedSize = documents.map(doc => ({
        ...doc,
        formattedSize: formatFileSize(doc.fileSize),
      }));

      res.json(documentsWithFormattedSize);
    } catch (error) {
      console.error("Error searching documents:", error);
      res.status(500).json({ message: "Failed to search documents" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
