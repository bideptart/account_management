# SecureDoc Pro - Document Management System

## Overview

SecureDoc Pro is a professional document management system built with a modern full-stack architecture. The application provides secure file upload, Google Drive integration, and role-based access control for managing business documents like bank receipts and financial files.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modular monolithic architecture with clear separation between frontend and backend concerns:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Framework**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Cloud Storage**: Google Drive API integration
- **File Handling**: Multer for file uploads with local storage buffer

## Key Components

### Authentication System
- **Provider**: Replit's OpenID Connect (OIDC) authentication
- **Session Management**: PostgreSQL-backed sessions using connect-pg-simple
- **Authorization**: Role-based access control with admin/user roles
- **Security**: HTTP-only cookies with 7-day TTL

### Database Schema
- **Users Table**: Stores user profiles with admin flags
- **Documents Table**: File metadata with Google Drive references
- **User Folders Table**: Maps users to their Google Drive folders
- **Sessions Table**: Manages user authentication sessions

### File Management
- **Upload Process**: Multi-file upload (up to 5 files, 10MB each)
- **Supported Formats**: PDF, DOC/DOCX, XLS/XLSX, CSV
- **Storage Strategy**: Temporary local storage → Google Drive → cleanup
- **Organization**: User-specific folders in Google Drive

### UI Components
- **Responsive Design**: Mobile-first approach with breakpoint utilities
- **Component Library**: Comprehensive set of reusable UI components
- **Theming**: Light/dark mode support with CSS custom properties
- **Accessibility**: ARIA-compliant components from Radix UI

## Data Flow

### File Upload Flow
1. User selects files via drag-and-drop or file picker
2. Client validates file types and sizes
3. Files uploaded to server with progress tracking
4. Server creates user-specific Google Drive folder (if needed)
5. Files transferred to Google Drive with metadata
6. Database records created with file references
7. Local temporary files cleaned up
8. Client receives success confirmation and refreshes document list

### Authentication Flow
1. User clicks login on landing page
2. Redirected to Replit OIDC provider
3. Successful authentication creates/updates user record
4. Session established with secure cookie
5. Client receives user data and navigates to dashboard

### Dashboard Access Flow
1. Client checks authentication status on load
2. Authenticated users see role-appropriate dashboard
3. Admins access system-wide document management
4. Regular users see personal document library
5. Unauthenticated users redirected to landing page

## External Dependencies

### Required Services
- **Database**: PostgreSQL (configured via DATABASE_URL)
- **Authentication**: Replit OIDC (ISSUER_URL, REPL_ID)
- **Google Drive**: Service account credentials for file storage
- **Session Security**: SESSION_SECRET for cookie signing

### Google Drive Integration
- Service account authentication with project credentials
- Automatic folder creation per user
- File upload with progress tracking
- Metadata synchronization with database

### Development Tools
- **Replit Integration**: Cartographer plugin for development
- **Error Handling**: Runtime error overlay for debugging
- **Hot Reload**: Vite HMR for rapid development

## Deployment Strategy

### Production Build
- **Frontend**: Vite builds optimized React bundle to `dist/public`
- **Backend**: ESBuild bundles server code to `dist/index.js`
- **Assets**: Static files served from built frontend

### Environment Configuration
- **Development**: Uses tsx for TypeScript execution with hot reload
- **Production**: Compiled JavaScript with NODE_ENV=production
- **Database**: Drizzle migrations managed via `db:push` script

### Security Considerations
- HTTP-only secure cookies for session management
- CORS configuration for cross-origin requests
- File type and size validation on upload
- User isolation through folder-based organization
- Admin role verification for sensitive operations

The architecture prioritizes security, scalability, and maintainability while providing a smooth user experience for document management workflows.