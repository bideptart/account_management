import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Eye, Download, Edit, Trash2, FileText, RotateCcw } from "lucide-react";
import { Document, User } from "@shared/schema";
import { useState } from "react";

interface AdminDocumentTableProps {
  documents: (Document & { user: User; formattedSize?: string })[];
  isLoading: boolean;
  onDocumentAction: (action: 'view' | 'download' | 'edit' | 'delete' | 'retry', document: Document & { user: User }) => void;
}

const getFileIcon = (fileType: string) => {
  switch (fileType.toLowerCase()) {
    case '.pdf':
      return '📄';
    case '.doc':
    case '.docx':
      return '📝';
    case '.xls':
    case '.xlsx':
      return '📊';
    case '.csv':
      return '📋';
    default:
      return '📄';
  }
};

const getFileTypeColor = (fileType: string) => {
  switch (fileType.toLowerCase()) {
    case '.pdf':
      return 'bg-red-100 text-red-800';
    case '.doc':
    case '.docx':
      return 'bg-blue-100 text-blue-800';
    case '.xls':
    case '.xlsx':
      return 'bg-green-100 text-green-800';
    case '.csv':
      return 'bg-orange-100 text-orange-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

const getSyncStatusColor = (status: string) => {
  switch (status) {
    case 'synced':
      return 'bg-green-100 text-green-800';
    case 'syncing':
      return 'bg-yellow-100 text-yellow-800';
    case 'failed':
      return 'bg-red-100 text-red-800';
    case 'pending':
      return 'bg-gray-100 text-gray-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
};

export function AdminDocumentTable({ documents, isLoading, onDocumentAction }: AdminDocumentTableProps) {
  const [selectedDocuments, setSelectedDocuments] = useState<Set<number>>(new Set());

  const handleSelectAll = () => {
    if (selectedDocuments.size === documents.length) {
      setSelectedDocuments(new Set());
    } else {
      setSelectedDocuments(new Set(documents.map(doc => doc.id)));
    }
  };

  const handleSelectDocument = (documentId: number) => {
    const newSelected = new Set(selectedDocuments);
    if (newSelected.has(documentId)) {
      newSelected.delete(documentId);
    } else {
      newSelected.add(documentId);
    }
    setSelectedDocuments(newSelected);
  };

  if (isLoading) {
    return (
      <div className="p-8 text-center">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
        <p className="text-gray-600">Loading documents...</p>
      </div>
    );
  }

  if (documents.length === 0) {
    return (
      <div className="p-8 text-center">
        <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">No documents found</h3>
        <p className="text-gray-600">No user documents are currently available.</p>
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead className="w-12">
            <Checkbox
              checked={selectedDocuments.size === documents.length}
              onCheckedChange={handleSelectAll}
            />
          </TableHead>
          <TableHead>User</TableHead>
          <TableHead>Document</TableHead>
          <TableHead>Type</TableHead>
          <TableHead>Size</TableHead>
          <TableHead>Upload Date</TableHead>
          <TableHead>Drive Status</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {documents.map((document) => {
          const userInitials = `${document.user.firstName?.[0] || ''}${document.user.lastName?.[0] || ''}`.toUpperCase() || document.user.email?.[0]?.toUpperCase() || 'U';
          const userName = `${document.user.firstName || ''} ${document.user.lastName || ''}`.trim() || document.user.email || 'User';

          return (
            <TableRow key={document.id} className="hover:bg-gray-50">
              <TableCell>
                <Checkbox
                  checked={selectedDocuments.has(document.id)}
                  onCheckedChange={() => handleSelectDocument(document.id)}
                />
              </TableCell>
              <TableCell>
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-medium">{userInitials}</span>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-900">{userName}</div>
                    <div className="text-sm text-gray-500">{document.user.email}</div>
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <div className="flex items-center space-x-3">
                  <div className="text-xl">
                    {getFileIcon(document.fileType)}
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-900">{document.originalName}</div>
                    <div className="text-sm text-gray-500">/users/{userName.toLowerCase().replace(/\s+/g, '_')}/documents/</div>
                  </div>
                </div>
              </TableCell>
              <TableCell>
                <Badge className={getFileTypeColor(document.fileType)}>
                  {document.fileType.toUpperCase().replace('.', '')}
                </Badge>
              </TableCell>
              <TableCell className="text-sm text-gray-900">
                {document.formattedSize || `${(document.fileSize / 1024 / 1024).toFixed(2)} MB`}
              </TableCell>
              <TableCell className="text-sm text-gray-900">
                {new Date(document.uploadedAt).toLocaleDateString()}
              </TableCell>
              <TableCell>
                <Badge className={getSyncStatusColor(document.syncStatus)}>
                  {document.syncStatus === 'synced' && '✓ Synced'}
                  {document.syncStatus === 'syncing' && '↻ Syncing'}
                  {document.syncStatus === 'failed' && '✗ Failed'}
                  {document.syncStatus === 'pending' && '⏳ Pending'}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <div className="flex items-center justify-end space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDocumentAction('view', document)}
                    className="text-primary hover:text-blue-800 hover:bg-blue-50"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDocumentAction('download', document)}
                    className="text-gray-600 hover:text-gray-800 hover:bg-gray-50"
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                  {document.syncStatus === 'failed' ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDocumentAction('retry', document)}
                      className="text-warning hover:text-yellow-800 hover:bg-yellow-50"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </Button>
                  ) : (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onDocumentAction('edit', document)}
                      className="text-warning hover:text-yellow-800 hover:bg-yellow-50"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDocumentAction('delete', document)}
                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          );
        })}
      </TableBody>
    </Table>
  );
}
