import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Upload, Users, Database } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="max-w-4xl mx-auto text-center">
        {/* Logo and Title */}
        <div className="mb-12">
          <div className="w-20 h-20 bg-primary rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Shield className="text-white text-4xl" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">SecureDoc Pro</h1>
          <p className="text-xl text-gray-600 mb-8">Professional Document Management System</p>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <Upload className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Secure Upload</h3>
              <p className="text-gray-600">Upload bank receipts and documents with enterprise-grade security</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <Database className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Cloud Storage</h3>
              <p className="text-gray-600">Automatic backup to Google Drive with organized folder structure</p>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-6 text-center">
              <Users className="w-12 h-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">User Management</h3>
              <p className="text-gray-600">Role-based access control with admin oversight capabilities</p>
            </CardContent>
          </Card>
        </div>

        {/* Login Button */}
        <Card className="bg-white rounded-2xl shadow-xl p-8 max-w-md mx-auto">
          <CardContent className="p-0">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Get Started</h2>
            <p className="text-gray-600 mb-6">
              Sign in to access your secure document vault and manage your files with professional-grade tools.
            </p>
            <Button 
              onClick={() => window.location.href = '/api/login'}
              className="w-full bg-primary hover:bg-blue-700 text-white py-3 px-6 rounded-lg font-medium text-lg"
            >
              Sign In to Continue
            </Button>
            <p className="text-sm text-gray-500 mt-4">
              Secure authentication powered by enterprise SSO
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
